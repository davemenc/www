<?php
/* $Id: config.php,v 1.2 2009/12/28 04:51:20 dmenconi Exp $ */
$magic_word="XnM1dLTAfTsituXmeSG2";
$cookiename = "janineweddingcookie";
$expiry=3000000000;
$username="guest";
$passphrase = "JANINEANDJASON";

$dbname="dmenconi";
$dbuser="dmenconi";
$dbpass="5guvt4wk";
$dbhost="localhost";

$lastchange="4/6/17";
$version="1.1";

?>
